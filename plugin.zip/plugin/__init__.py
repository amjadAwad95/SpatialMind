# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SQLQueryPlugin
                                 A QGIS plugin
 Convert natural language to SQL and add as layers
                             -------------------
        begin                : 2025-01-01
        copyright            : (C) 2025 by Your Name
        email                : your.email@example.com
        git sha              : $Format:%H$
 ***************************************************************************/
"""


import os
import sys

# Add plugin directory to Python path
plugin_dir = os.path.dirname(__file__)
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)


def classFactory(iface):
    """Load SpatialMindPlugin class from file sql_query_plugin.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    from .sql_query_plugin import SQLQueryPlugin

    return SQLQueryPlugin(iface)